
document.addEventListener("DOMContentLoaded", () => {
  const fadeElements = document.querySelectorAll('.fade-in');
  fadeElements.forEach((el, index) => {
    el.style.animationDelay = `${index * 0.3}s`;
  });

  // Dark Mode Toggle
  const toggleBtn = document.createElement('button');
  toggleBtn.innerText = '🌓 Mode';
  toggleBtn.className = 'toggle-btn';
  toggleBtn.onclick = () => {
    document.body.classList.toggle('dark');
  };
  document.body.appendChild(toggleBtn);
});
